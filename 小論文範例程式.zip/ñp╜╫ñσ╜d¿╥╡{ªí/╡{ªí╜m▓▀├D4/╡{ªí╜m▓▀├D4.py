import docx


taiwancity = ["台中市","高雄市","台北市","新北市","台南市","桃園市"]


doc = docx.Document("MultiLayList_template.docx")

para  = doc.paragraphs[0]
para.text = "台灣六都"
para.style = "Normal"

for city in taiwancity:
    para = doc.add_paragraph(city,style="List Bullet")

for city in taiwancity:
    para = doc.add_paragraph(city,style="Heading 1")


doc.save("程式練習題4.docx")
