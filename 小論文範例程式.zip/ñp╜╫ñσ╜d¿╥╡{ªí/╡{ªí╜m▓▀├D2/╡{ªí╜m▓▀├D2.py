import docx


doc = docx.Document("MultiLayList_template.docx")

para1 = doc.paragraphs[0]
para1.text = "台中市"
para1.style = "Heading 1"

para2 = doc.add_paragraph("西屯區",style="Heading 2")
para3 = doc.add_paragraph("文心路",style="Heading 3")
para4 = doc.add_paragraph("青海路",style="Heading 3")
para5 = doc.add_paragraph("台灣大道",style="Heading 3")


doc.save("程式練習題2.docx")
