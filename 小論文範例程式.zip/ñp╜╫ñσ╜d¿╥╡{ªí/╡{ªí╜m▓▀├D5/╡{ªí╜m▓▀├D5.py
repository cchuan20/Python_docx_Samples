import docx


taiwancity = ["台中市","高雄市","台北市","新北市","台南市","桃園市"]


doc = docx.Document("MultiLayList_template.docx")

para  = doc.paragraphs[0]
para.text = "台灣六都"
para.style = "Normal"

for city in taiwancity:
    para = doc.add_paragraph(city,style="List Bullet")
    tb   = doc.add_table(rows = 2,cols = 3 ,style = "Table Grid")
    doc.add_paragraph()

for city in taiwancity:
    para = doc.add_paragraph(city,style="Heading 1")
    tb   = doc.add_table(rows = 8,cols = 3 ,style = "Table Grid")
    

doc.save("程式練習題5.docx")
