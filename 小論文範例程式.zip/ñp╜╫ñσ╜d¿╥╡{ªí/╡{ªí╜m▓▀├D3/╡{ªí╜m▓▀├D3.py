import docx

doc = docx.Document("MultiLayList_template.docx")

para  = doc.paragraphs[0]
para.text = "台灣六都"
para.style = "Normal"

para1 = doc.add_paragraph("台中市",style="Heading 1")
para2 = doc.add_paragraph("高雄市",style="Heading 1")
para3 = doc.add_paragraph("台北市",style="Heading 1")
para4 = doc.add_paragraph("新北市",style="Heading 1")
para5 = doc.add_paragraph("台南市",style="Heading 1")
para5 = doc.add_paragraph("桃園市",style="Heading 1")

doc.save("程式練習題3.docx")
