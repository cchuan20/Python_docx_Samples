import docx
from docx.oxml.shared import OxmlElement,qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.shared import RGBColor
import os,sys

#------------------------------------------------------------------------

def create_element(name):
    return OxmlElement(name)

def create_attribute(element, name, value):
    element.set(qn(name),value)
    return None

def add_page_number(para):
    run = para.add_run()
    fldChar1 = create_element('w:fldChar')
    create_attribute(fldChar1, 'w:fldCharType', 'begin')
    instrText = create_element('w:instrText')
    create_attribute(instrText, 'xml:space', 'preserve')
    instrText.text = "PAGE \* ArabicDash"
    fldChar2 = create_element('w:fldChar')
    create_attribute(fldChar2, 'w:fldCharType', 'end')
    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)
    return None

def generateTOC(para):
    run = para.add_run()
    run.font.name = u'標楷體'
    run.font.color.rgb = RGBColor(0xff,0x00,0x00)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), u'標楷體')
    fldChar = create_element('w:fldChar')
    create_attribute(fldChar,'w:fldCharType', 'begin')
    instrText = create_element('w:instrText')
    create_attribute(instrText,'xml:space', 'preserve')
    instrText.text = 'TOC \\o "1-3" \\h \\z \\u'
    fldChar2 = create_element('w:fldChar')
    create_attribute(fldChar2,'w:fldCharType', 'separate')
    fldChar3 = create_element('w:t')
    fldChar3.text = u"在此按右鍵更新功能變數"
    fldChar2.append(fldChar3)
    fldChar4 = create_element('w:fldChar')
    create_attribute(fldChar4,'w:fldCharType', 'end')
    r_element = run._r
    r_element.append(fldChar)
    r_element.append(instrText)
    r_element.append(fldChar2)
    r_element.append(fldChar4)
    return None

def create_page_number_type(section,start_num: int=1): 
    num_type = OxmlElement('w:pgNumType')
    num_type.set(qn('w:start'), str(start_num))
    tag = section._sectPr.append(num_type)
    return None

#------------------------------------------------------------------------

my_file = os.path.dirname(__file__)
myfilepath = my_file + '\\' + '程式練習題10.docx'

taiwancity = ["台中市","高雄市","台北市","新北市","台南市","桃園市"]

doc = docx.Document("MultiLayList_template.docx")
para = doc.paragraphs[0]
para.text = "目錄"
para.style = "Normal"
generateTOC(para)


section0 = doc.sections[0]
doc.add_page_break()
section1 = doc.add_section(WD_SECTION.NEW_PAGE)
create_page_number_type(section1,start_num=1) 


para  = doc.add_paragraph()
para.text = "台灣六都"
para.style = "Normal"

for city in taiwancity:
    para = doc.add_paragraph(city,style="List Bullet")
    tb   = doc.add_table(rows = 2,cols = 3 ,style = "Table Grid")
    doc.add_paragraph()

for city in taiwancity:
    para = doc.add_paragraph(city,style="Heading 1")
    tb   = doc.add_table(rows = 8,cols = 3 ,style = "Table Grid")


header  = section1.header
header.is_linked_to_previous=False
header_para = header.paragraphs[0]
header_para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
header_para.text = "程式練習題10"

footer  = section1.footer
footer.is_linked_to_previous=False
footer_para = footer.paragraphs[0]
footer_para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
add_page_number(footer_para)
  

doc.save(myfilepath)


import win32com.client
word = win32com.client.DispatchEx("Word.Application")
doc1 = word.Documents.Open(myfilepath)
doc1.TablesOfContents(1).Update()
doc1.Close(SaveChanges=True)










