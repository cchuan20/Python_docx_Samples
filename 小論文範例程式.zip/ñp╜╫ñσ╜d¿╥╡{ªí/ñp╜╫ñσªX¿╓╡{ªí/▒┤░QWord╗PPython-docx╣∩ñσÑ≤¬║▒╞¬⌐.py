#----------------------------------------
# 小論文合併程式 2023.02.28
# 台中市立忠明高級中學
# 三年一班 黃士緯
#----------------------------------------

import docx
import os,sys
from docx.enum.table import WD_ROW_HEIGHT
from docx.shared import Pt,Cm
from docx.enum.section import WD_ORIENT
from docx.oxml.shared import OxmlElement,qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

def create_element(name):
    return OxmlElement(name)

def create_attribute(element, name, value):
    element.set(qn(name),value)
    return None

def add_page_number_arabic(para):
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run()
    fldChar1 = create_element('w:fldChar')
    create_attribute(fldChar1, 'w:fldCharType', 'begin')
    instrText = create_element('w:instrText')
    create_attribute(instrText, 'xml:space', 'preserve')
    instrText.text = "PAGE \* ArabicDash MERGEFORMAT"
    fldChar2 = create_element('w:fldChar')
    create_attribute(fldChar2, 'w:fldCharType', 'end')
    run._r.append(fldChar1)
    run._r.append(instrText)
    run._r.append(fldChar2)
    return None


def Incldetxt(doc,paragraph,strtxt):
    para = paragraph._p
    run = paragraph.add_run()
    runtag = run._r
    fldChar = OxmlElement('w:fldChar')
    fldChar.set(qn('w:fldCharType'),'begin')
    runtag.append(fldChar)
    para.append(runtag)
    run1 = paragraph.add_run()
    run1tag = run1._r
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'),'preserve') 
    instrText.text = strtxt    
    run1tag.append(instrText)
    para.append(run1tag)
    run2 = paragraph.add_run()
    run2tag=run2._r
    fldChar = OxmlElement('w:fldChar')    
    fldChar.set(qn('w:fldCharType'),'separate')
    run2tag.append(fldChar)
    para.append(run2tag)
    para2 = doc.add_paragraph()
    para2tag = para2._p
    run3 = para2.add_run()
    run3tag = run3._r
    fldChar = OxmlElement('w:fldChar')
    fldChar.set(qn('w:fldCharType'),'end')
    run3tag.append(fldChar)
    para2tag.append(run3tag)
    bookmarkS = OxmlElement('w:bookmarkStart') 
    bookmarkS.set(qn('w:name'),'_GoBack') 
    bookmarkS.set(qn('w:id'),'0') 
    bookmarkE = OxmlElement('w:bookmarkEnd') 
    bookmarkE.set(qn('w:id'),'0') 
    para2tag.append(bookmarkS)
    para2tag.append(bookmarkE)
    return None 


my_file_path = os.path.dirname(__file__)
my_file      = my_file_path + '\\' + '探討Word與Python-docx對文件的排版.docx'
my_template  = my_file_path + '\\' + 'template2.docx'

doc = docx.Document(my_template)

section0 = doc.sections[0]
header0  = section0.header
headpara = header0.paragraphs[0]
headpara.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
headpara.text = "探討Word與Python-docx對文件的排版"

footer0    = section0.footer
footerpara = footer0.paragraphs[0]
add_page_number_arabic(footerpara)


mypath1 = my_file_path.replace("\\","\\\\")
mypath2 = mypath1 + '\\\\'

include_string1 = "INCLUDETEXT "+ mypath2+"前言.docx" +"\* MERGEFORMAT"
include_string2 = "INCLUDETEXT "+ mypath2+"文獻探討.docx" +"\* MERGEFORMAT"
include_string3 = "INCLUDETEXT "+ mypath2+"研究方法.docx" +"\* MERGEFORMAT"
include_string4 = "INCLUDETEXT "+ mypath2+"研究分析與結果.docx" +"\* MERGEFORMAT"
include_string5 = "INCLUDETEXT "+ mypath2+"研究結論與建議.docx" +"\* MERGEFORMAT"
include_string6 = "INCLUDETEXT "+ mypath2+"參考文獻.docx" +"\* MERGEFORMAT"


para1 = doc.paragraphs[0]
para1.style = 'Heading 1'
#para1 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para1,include_string1)

para2 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para2,include_string2)

para3 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para3,include_string3)

para4 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para4,include_string4)

para5 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para5,include_string5)

para6 = doc.add_paragraph(style='Heading 1')
Incldetxt(doc,para6,include_string6)


doc.save(my_file)

#-------------------------------------------------------

import win32com.client
word = win32com.client.DispatchEx("Word.Application")
doc1 = word.Documents.Open(my_file)
doc1.Fields.Update()
doc1.Close(SaveChanges=True)



